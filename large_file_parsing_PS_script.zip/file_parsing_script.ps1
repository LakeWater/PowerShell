﻿#===========================================================
#==	Author:	Samantha Budd
#==	Date:	07/11/2020
#==	Purpose:Parse large text files w/multiple conditions.
#== For a written guide on the use of this script, visit eskay.be/blog
#== this script must be ran with a $input_file value (filename with extension)
#===========================================================

param ([string]$input_file = '')

#===========================================================
#=============== DATE VARIABLES ============================
#===========================================================
#store the time the task started
$start_time = get-date
$report_date_MMddyyyy = (get-date).tostring('MMddyyyy')

#===========================================================
#============== WORKING LOCATION VARIABLES =================
#===========================================================
$report_file_source = 'C:\Temp\File_Parsing\Source\' + $input_file
write-host $report_file_source
$report_file_staging = 'C:\Temp\File_Parsing\Staging\' + $input_file
$report_archive_folder = 'C:\Temp\File_Parsing\Processed\'
$report_file_archive = $report_archive_folder + $input_file
$report_output_location = 'C:\Temp\File_Parsing\Reports\' + $report_date_MMddyyyy + '\'

copy-item $report_file_source $report_file_staging -force


#===========================================================
#=============== LOGGING SET UP ============================
#===========================================================
$file_to_parse = get-childitem $report_file_source
$filename_of_file = $file_to_parse.BaseName
$logfile = 'C:\scripts\logs\' + $filename_of_file + '_parsing_log.txt'
$now = get-date
add-content $logfile "=================== Script started at: $now ==================="

#===========================================================
#================= REPORT INFORMATION ======================
#===========================================================

# this is only in here to remind you that sometimes the information is stored somewhere easier to pull
# instead of creating arrays to start data within the script itself
<#$SQL_servername = 'some_SQL_server'
$database = 'some_database'
$reports_query = "SELECT [reportname] FROM [some_database].[dbo].[Report_Names]"
$reports_wanted = invoke-sqlcmd -serverInstance $SQL_servername -database $database -query $reports_query | select -Expand reportname#>
$reports_wanted = @("REPORTTYPE1","REPORTTYPE2","NORMIETYPE1","NORMIETYPE2","NORMIETYPE3")

#===========================================================
#================= DEPARTMENT INFORMATION ==================
#===========================================================

$current_departments = @(51,8,900,42,36)
$current_departments_count = $current_departments.count

$now = get-date
$message = ("$now : INFO - parsing reports for " + $current_departments_count + " departments.")
write-host $message -foregroundcolor green
add-content $logfile $message
add-content $logfile "==========================================================================="

$beginning_page_indicator = 1 #this can be designated as something else, just make sure to update the substring on line 84

#===========================================================
#=============== START ACTUAL PARSING OF FILE ==============
#===========================================================

$staged_file = get-childitem -Path $report_file_staging

$now = get-date
$message = ("$now : INFO - Starting parsing for file: " + $input_file)
write-host $message -foregroundcolor green
add-content $logfile $message
add-content $logfile "==========================================================================="

#use .NET to read through files faster
$reader = New-Object System.IO.StreamReader($staged_file)

#loop through the file, reading each line until there aren't any lines left
while (($line = $reader.ReadLine()) -ne $null)
{
	write-host $line
	#reads first character of the line to see if it starts with a '1' (as dictated above on line 63); indicates new report page
	if ($line.substring(0,1) -eq $beginning_page_indicator)
	{
		#clear out report conditional variables
		$report_type = ''
		$department_from_report = ''
		$page_counter = 0
		$page_counter++
		
		#since the script found a new page, close any writers
		if ($writer)
		{
			$writer.Close()
			$writer = $null
		}
		
		#the length of the line which normally has the page number
		if ($line.length -gt 127)
		{			
			$page_number = $line.substring(127,$line.length - 127)
			$page_number = $page_number.trim()
		}
	}
	
	if ($line.length -ge 128)
	{	
		$report_type = $line.substring(121,$line.length - 121)
		
		$report_type = $report_type.trim()
		
		if ($reports_wanted -contains $report_type)
		{	
			if ($report_type -eq 'REPORTTYPE1') #report type with a variation from others
			{
				$department_from_report = $line.substring(1,15)
				$department_from_report = $department_from_report.trim()
				$department_from_report = $department_from_report -replace '[^0-9]'
			}
			elseif ($report_type -eq 'REPORTTYPE2') #report type with a variation from others
			{
				$department_from_report = $line.substring(1,7)
				$department_from_report = $department_from_report.trim()
				$department_from_report = $department_from_report -replace '[^0-9]'	
				
				#unlike the other reports, the page number is not in the same line as the new page indicator
				$page_number = $previous_line.substring(127,$previous_line.length - 127)
				$page_number = $page_number.trim()
			}			
			else #all other normal reports
			{
				$department_from_report = $line.substring(1,7)
				$department_from_report = $department_from_report.trim()
				$department_from_report = $department_from_report -replace '[^0-9]'			
			}
						
			$department_rollup = @()
			
			if ($department_from_report -ne '')
			{
				foreach ($department_ID in $current_departments)
				{
					$padded_department = ([string]$department_ID).PadLeft(3,'0')
					$padded_department_from_report = ([string]$department_from_report).PadLeft(3,'0')
							
					if ($padded_department_from_report -eq $padded_department)
					{
						$department_rollup += $department_ID
					}
				}				
			}
			
			if ($department_rollup.count -eq 0)
			{
				$department_rollup += 'Unknown' 
				
				$now = get-date
				$message = "$now : INFO - an unknown report was found: $department_from_report, $padded_department_from_report"
				write-host $message -foregroundcolor yellow
				add-content $logfile $message
			}
			
			$now = get-date
			$message = "$now : INFO - a report type has been found: $report_type - page: $page_number"
			write-host $message
			#uncomment this line to output found reports to the log file
			#add-content $logfile $message
			
			$output_file = $report_type + '_page_' + $page_number + '.txt'
			$output_file2 = $report_type + '_page_' + $page_number + '_2_.txt'
		
			if ($writer)
			{
				$writer.Close()
				$writer = $null
			}			

			foreach ($department in $department_rollup)
			{				                
				$output_file_department_folder = $report_output_location + $department
				$output_file_report_folder = $output_file_department_folder + '\' + $report_type
				$output_file_fullname = $output_file_report_folder + '\' + $output_file
						
				#create directory locations for creating texts to
				if (-not(test-path $output_file_department_folder))
				{
					new-item $output_file_department_folder -itemtype directory -force | out-null
				}
				
				if (-not(test-path $output_file_report_folder))
				{
					new-item $output_file_report_folder -itemtype directory -force | out-null
				}			
				
				if (-not(test-path $output_file_fullname))
				{
					new-item $output_file_fullname -itemtype file -force | out-null
					$counter++
				}
				else
				{
					$output_file_fullname = $output_file_report_folder + '\' + $output_file2
					new-item $output_file_fullname -itemtype file -force | out-null
					$counter++
				}
				
				#if the report type found in line 113 is a wanted report, then open the writer
				# to start outputting the page to the folder location set above in lines 182-184
				$writer = New-Object System.IO.StreamWriter($output_file_fullname)
				
				if ($previous_line.length -ge 1)
				{
					$prevline_sub = $previous_line.substring(0,1)
					# sample file has values in the first column. this trims these values
					# however, if you do not need the first value trimmed from the output line
					# then just remove the switch and replace it with:
					# $writer.writeline($previous_line)
					switch ($prevline_sub)
					{
					   '-' {
							$writer.writeline($previous_line.substring(1,$previous_line.length - 1))                
						}
					   '+' {
							$writer.writeline($previous_line.substring(1,$previous_line.length - 1))                
						}
					   default {
							$writer.writeline($previous_line.substring(1,$previous_line.length - 1))                
						}
					}
				}
				else
				{
					#if line is empty in at check on 212, just insert a blank line
					$writer.writeline('')
				}
			}
		}
	}
	
	#assign current line to the $previous_line variable
	$previous_line = $line
	
	if ($writer)
	{
		if ($line.length -ge 1)
		{
			$line_sub = $line.substring(0,1)
			# sample file has values in the first column. this trims these values
			# however, if you do not need the first value trimmed from the output line
			# then just remove the switch and replace it with:
			# $writer.writeline($line)
			switch ($line_sub)
			{
				'-' {
					$writer.writeline($line.substring(1,$line.length - 1))                
				}
				'+' {
					$writer.writeline($line.substring(1,$line.length - 1))                
				}
				default {
					$writer.writeline($line.substring(1,$line.length - 1))                
				}
			}
		}
		else
		{
			$writer.writeline('')
		}
	}
}

$reader.close()
$writer.Close()

$now = get-date
$message = "$now : INFO - $counter reports were produced."
write-host $message
add-content $logfile $message

#get the current time for logging
$finish_time = get-date

$now = get-date
$message = "$now : INFO - parsing completed at $finish_time."
write-host $message
add-content $logfile $message

#calculate the total runtime
$total_runtime = new-timespan $start_time $finish_time

$now = get-date
$message = "$now : INFO - report parsing completed at $finish_time and took $total_runtime to complete. It produced $counter reports."
write-host $message
add-content $logfile $message

if ($errors)
{
	add-content $logfile "===================================================="
	add-content $logfile "The following errors occurred during script execution"
	add-content $logfile $errors
}

#cleanup temp files
move-item $report_file_source $report_file_archive -force